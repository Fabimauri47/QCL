
def teoria(a,b):
    teoria_final = ""
    for i in range(0,3):
        if a[i] != b[i]:
            teoria_final+="1"
        else:
            teoria_final+="0"
    return teoria_final

def comvertir_binario(num1,num2):
    contenido = ""
    if(num2<6):
        contenido += str(num1%2)        
        contenido +=comvertir_binario(num1//2,num2+1)
    return contenido


def poblando(j):
    a = binaria[j]         
    sbs = a[3:]
    if (sbs == "000" or sbs == "010"):
        index = a[:3]+teoria("101",sbs)
        valor = binaria.index(index)
        matriz[valor][j] = 1

    elif (sbs == "001" or sbs == "011"):
        index = a[:3]+teoria("000",sbs)
        valor = binaria.index(index)
        matriz[valor][j] = 1

    elif (sbs == "100" or sbs == "110"):
        index = a[:3]+teoria("011",sbs)
        valor = binaria.index(index)
        matriz[valor][j] = 1

    elif (sbs == "101" or sbs == "111"):
        index = a[:3]+teoria("111",sbs)
        valor = binaria.index(index)
        matriz[valor][j] = 1

def solucion():
    for i in range(64):
        for j in range(64):
            poblando(j)
           
def main():
    global binaria
    global matriz
    binaria = [comvertir_binario(i,0)[::-1] for i in range(0,64)]
    matriz = [[0 for i in range(0,64)] for j in range(0,64)]
    
    solucion()
    for i in matriz:
        print(*i)
main()

